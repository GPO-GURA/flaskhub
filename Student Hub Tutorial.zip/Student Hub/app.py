from flask import Flask, render_template, request, redirect, url_for, flash
from flask_login import LoginManager, UserMixin, login_required, login_user, current_user, logout_user
import sqlite3
from flask_bcrypt import Bcrypt

app= Flask(__name__)
bcrypt = Bcrypt(app)
app.config['SECRET_KEY'] = 'thisIsSecret'
login_manager = LoginManager(app)
login_manager.login_view="login"

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/reportabsence')
def reportabsence():
    return render_template('reportabsence.html')

def is_admin():
    # return current_user.is_authenticated and current_user.email == "admin@mail.com"
    return current_user.is_authenticated

@app.route('/events')
def events():
    con = sqlite3.connect("events.db")
    curs = con.cursor()
    curs.execute("""
        SELECT id, title, description, created_at
        FROM events
        ORDER BY created_at DESC
    """)
    events = curs.fetchall()
    con.close()
    return render_template('events.html', events=events)

@app.route('/delete-event/<int:event_id>', methods=['POST'])
@login_required
def delete_event(event_id):
    con = sqlite3.connect("events.db")
    curs = con.cursor()
    curs.execute("DELETE FROM events WHERE id = ?", (event_id,))
    con.commit()
    con.close()

    return redirect(url_for('events'))

@app.route('/edit-event/<int:event_id>', methods=['GET', 'POST'])
@login_required
def edit_event(event_id):
    con = sqlite3.connect("events.db")
    curs = con.cursor()

    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']

        curs.execute("""
            UPDATE events
            SET title = ?, description = ?
            WHERE id = ?
        """, (title, description, event_id))
        con.commit()
        con.close()

        return redirect(url_for('events'))

    curs.execute("SELECT title, description FROM events WHERE id = ?", (event_id,))
    event = curs.fetchone()
    con.close()

    return render_template('edit_event.html', event=event)


@app.route('/create-event', methods=['GET', 'POST'])
@login_required
def createevent():
    if not is_admin():
        flash("Access denied.")
        return redirect(url_for('home'))

    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']

        con = sqlite3.connect("events.db")
        curs = con.cursor()
        curs.execute(
            "INSERT INTO events (title, description, created_by) VALUES (?, ?, ?)",
            (title, description, current_user.id)
        )
        con.commit()
        con.close()

        flash("Event created successfully!")
        return redirect(url_for('events'))

    return render_template('createevent.html')


@app.route('/login')
def login():
    return render_template('login.html')
    
class User(UserMixin):
    def __init__(self,id,email,password):
        self.id = id
        self.email = email
        self.password = password
        self.authenticated = False
        def is_active(self):
            return self.is_active()
        def is_anonymous(self):
            return False
        def is_authenticated(self):
            return self.authenticated
        def is_active(self):
            return True
        def get_id(self):
            return self.id

@app.route("/login", methods=["POST"])
def login_post():
    print("Start")
    if current_user.is_authenticated:
        print("authenticated kid")
        return redirect(url_for('home'))
    con=sqlite3.connect("login.db")
    curs = con.cursor()
    email = request.form["email"]
    curs.execute("SELECT * FROM login where email = (?)", [email])
    row=curs.fetchone()
    if row==None:
        print("sigma")
        flash('please try logging in again')
        return render_template('login.html')
    user = list(row)
    liUser = User(int(user[0]),user[1],user[2])
    password = request.form['password']
    match = bcrypt.check_password_hash(liUser.password,password)
    if match and email==liUser.email:
        print("Ik u")
        login_user(liUser,remember=request.form.get('remember'))
        redirect(url_for('home'))
    else:
        print("failed login")
        flash('Please try logging in again')
        return render_template ('login.html')
    print("idk wtf ts for")
    return redirect(url_for('home'))

@login_manager.user_loader
def load_user(user_id):
    conn = sqlite3.connect('login.db')
    curs=conn.cursor()
    curs.execute("SELECT * from login where user_id = (?)", [user_id])
    liUser = curs.fetchone()
    if liUser is None:
        return None
    else:
        return User(int(liUser[0]),liUser[1],liUser[2])
    
@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for('home'))

@app.route('/register')
def register():
    return render_template("register.html")

@app.route('/register', methods=['POST'])
def register_post():
    if current_user.is_authenticated:
        return redirect(url_for('home'))
    
    con=sqlite3.connect("login.db")
    curs = con.cursor()
    email = request.form['email']
    password = request.form['password']
    hashedPassword=bcrypt.generate_password_hash(password)
    emailCheck = con.execute('SELECT * FROM login WHERE email LIKE ?', (email,))

    hasEmail = emailCheck.fetchone()
    print(hasEmail)
    
    if hasEmail == None:
        con.execute('insert into login (email,password) VALUES (?,?)', [email,hashedPassword])
        con.commit()
        return render_template('home.html')
    else:
        flash('Email already registered.')
        return render_template ('register.html')

app.debug=True
app.run()