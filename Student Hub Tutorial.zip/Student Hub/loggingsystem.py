import sqlite3

conn = sqlite3.connect("login2.db")
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS login (
    user_id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL
)
""")

conn.commit()
conn.close()
